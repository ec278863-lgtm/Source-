// Builds ONE self-contained index.html (no server) for GitHub Pages: node build-static.mjs
import * as esbuild from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const opts = { bundle: true, minify: true, write: false, target: 'es2020', jsx: 'automatic', outdir: 'out' };
const js = (await esbuild.build({ ...opts, entryPoints: ['web/src/main.tsx'], format: 'iife',
  define: { 'process.env.NODE_ENV': '"production"', __STATIC__: 'true' } })).outputFiles[0].text;
const css = (await esbuild.build({ ...opts, entryPoints: ['web/src/styles.css'] })).outputFiles[0].text;
const icon = 'data:image/svg+xml;base64,' + readFileSync('web/public/icon.svg').toString('base64');

const html = readFileSync('web/public/index.html', 'utf8')
  .replace('href="/icon.svg"', `href="${icon}"`)
  .replace('<link rel="stylesheet" href="/styles.css" />', () => `<style>${css}</style>`)
  .replace('<script src="/app.js"></script>', () => `<script>${js.replaceAll('"/icon.svg"', JSON.stringify(icon)).replaceAll('</script', '<\\/script')}</script>`);

mkdirSync('docs', { recursive: true });
writeFileSync('docs/index.html', html);
console.log(`docs/index.html written (${(html.length / 1024).toFixed(0)} KB)`);
