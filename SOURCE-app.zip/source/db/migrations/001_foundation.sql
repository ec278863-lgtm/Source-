-- SOURCE foundation schema. Portable: runs on SQLite (dev) and PostgreSQL (prod).
-- IDs are app-generated UUID strings. Booleans are INTEGER 0/1. Timestamps are ISO text.

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student'
    CHECK (role IN ('student','teacher','school_rep','src_officer','moderator','admin')),
  verification_status TEXT NOT NULL DEFAULT 'not_required'
    CHECK (verification_status IN ('not_required','pending','verified','rejected')),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  guardian_consent INTEGER NOT NULL DEFAULT 0 CHECK (guardian_consent IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX users_username_uq ON users (username);

CREATE TABLE sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX sessions_token_uq ON sessions (token_hash);
CREATE INDEX sessions_user_idx ON sessions (user_id);

CREATE TABLE student_profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  class_level TEXT CHECK (class_level IN ('JHS1','JHS2','JHS3','SHS1','SHS2','SHS3')),
  exam_target TEXT CHECK (exam_target IN ('BECE','WASSCE')),
  exam_date TEXT,                 -- set by the student; never guessed by SOURCE
  daily_goal_minutes INTEGER NOT NULL DEFAULT 30 CHECK (daily_goal_minutes BETWEEN 5 AND 600),
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id TEXT,
  details TEXT,                   -- JSON
  ip TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX audit_logs_created_idx ON audit_logs (created_at);
CREATE INDEX audit_logs_actor_idx ON audit_logs (actor_id);

-- Examination knowledge base (Stage 2 builds on these)
CREATE TABLE exams (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL,             -- BECE, WASSCE
  name TEXT NOT NULL,
  level TEXT NOT NULL CHECK (level IN ('JHS','SHS'))
);
CREATE UNIQUE INDEX exams_code_uq ON exams (code);

CREATE TABLE subjects (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL,
  name TEXT NOT NULL
);
CREATE UNIQUE INDEX subjects_slug_uq ON subjects (slug);

CREATE TABLE exam_subjects (
  exam_id TEXT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  subject_id TEXT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  category TEXT NOT NULL CHECK (category IN ('core','elective')),
  PRIMARY KEY (exam_id, subject_id)
);

CREATE TABLE sources (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  url TEXT,
  publisher TEXT,
  licence TEXT,
  usage_status TEXT NOT NULL DEFAULT 'unknown'
    CHECK (usage_status IN ('permitted','attribution_required','restricted','unknown')),
  retrieved_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE syllabus_versions (
  id TEXT PRIMARY KEY,
  subject_id TEXT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  exam_id TEXT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  version_label TEXT NOT NULL,
  effective_from TEXT,
  effective_to TEXT,              -- NULL = current
  source_id TEXT REFERENCES sources(id) ON DELETE SET NULL
);
CREATE INDEX syllabus_subject_idx ON syllabus_versions (subject_id, exam_id);

CREATE TABLE topics (
  id TEXT PRIMARY KEY,
  syllabus_version_id TEXT NOT NULL REFERENCES syllabus_versions(id) ON DELETE CASCADE,
  parent_id TEXT REFERENCES topics(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  learning_objective TEXT,
  position INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX topics_syllabus_idx ON topics (syllabus_version_id);

CREATE TABLE past_papers (
  id TEXT PRIMARY KEY,
  exam_id TEXT NOT NULL REFERENCES exams(id),
  subject_id TEXT NOT NULL REFERENCES subjects(id),
  year INTEGER NOT NULL CHECK (year BETWEEN 1950 AND 2100),
  session TEXT,                   -- e.g. May/June, Nov/Dec, private
  paper_number TEXT NOT NULL,
  paper_type TEXT NOT NULL CHECK (paper_type IN ('objective','theory','practical')),
  syllabus_version_id TEXT REFERENCES syllabus_versions(id),
  source_id TEXT REFERENCES sources(id),
  verification_status TEXT NOT NULL DEFAULT 'unverified'
    CHECK (verification_status IN ('verified','under_review','unverified','restricted'))
);
CREATE UNIQUE INDEX past_papers_uq ON past_papers (exam_id, subject_id, year, session, paper_number);

CREATE TABLE questions (
  id TEXT PRIMARY KEY,
  past_paper_id TEXT REFERENCES past_papers(id) ON DELETE CASCADE,  -- NULL = practice question
  question_number TEXT,
  body TEXT NOT NULL,
  answer_type TEXT NOT NULL CHECK (answer_type IN ('mcq','short','theory','essay','calculation','diagram','practical')),
  marks INTEGER,                  -- only when verified
  verification_status TEXT NOT NULL DEFAULT 'unverified'
    CHECK (verification_status IN ('verified','under_review','unverified','restricted')),
  source_id TEXT REFERENCES sources(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX questions_paper_idx ON questions (past_paper_id);

CREATE TABLE question_options (
  id TEXT PRIMARY KEY,
  question_id TEXT NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  body TEXT NOT NULL,
  is_correct INTEGER NOT NULL DEFAULT 0 CHECK (is_correct IN (0,1)),
  why_wrong TEXT
);
CREATE INDEX question_options_q_idx ON question_options (question_id);

CREATE TABLE question_dna (
  question_id TEXT PRIMARY KEY REFERENCES questions(id) ON DELETE CASCADE,
  topic_id TEXT REFERENCES topics(id) ON DELETE SET NULL,
  concept TEXT,
  skill TEXT,
  difficulty INTEGER CHECK (difficulty BETWEEN 1 AND 5),
  method TEXT,
  family_key TEXT                 -- groups recurring question families
);
CREATE INDEX question_dna_topic_idx ON question_dna (topic_id);
CREATE INDEX question_dna_family_idx ON question_dna (family_key);

CREATE TABLE attempts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  question_id TEXT NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  answer TEXT,
  is_correct INTEGER CHECK (is_correct IN (0,1)),
  score REAL,
  grading TEXT NOT NULL DEFAULT 'auto' CHECK (grading IN ('auto','scheme','ai_estimate','human')),
  time_spent_s INTEGER,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX attempts_user_idx ON attempts (user_id, created_at);
