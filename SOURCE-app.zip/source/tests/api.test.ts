import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { randomUUID } from 'node:crypto';
import { openDb } from '../server/db.ts';
import { createApp } from '../server/app.ts';
import { hashPassword } from '../server/auth.ts';

const db = openDb(':memory:');
const server = createApp(db);
let base = '';
before(() => new Promise<void>(r => server.listen(0, () => { base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`; r(); })));
after(() => server.close());

async function call(method: string, path: string, body?: unknown, token?: string) {
  const res = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: res.status, json: await res.json() as any };
}

let studentToken = '';
let adminToken = '';

test('subjects are seeded', async () => {
  const r = await call('GET', '/api/subjects');
  assert.equal(r.status, 200);
  assert.ok(r.json.subjects.length >= 10);
});

test('register validates input', async () => {
  const r = await call('POST', '/api/auth/register', { username: 'a', password: 'short', displayName: '' });
  assert.equal(r.status, 400);
});

test('register, duplicate, login, me', async () => {
  const r = await call('POST', '/api/auth/register', { username: 'Ama_K', password: 'goodpass123', displayName: 'Ama', examTarget: 'BECE', classLevel: 'JHS3' });
  assert.equal(r.status, 200);
  assert.equal((await call('POST', '/api/auth/register', { username: 'ama_k', password: 'goodpass123', displayName: 'X' })).status, 409);
  assert.equal((await call('POST', '/api/auth/login', { username: 'ama_k', password: 'wrongpass1' })).status, 401);
  const l = await call('POST', '/api/auth/login', { username: 'ama_k', password: 'goodpass123' });
  studentToken = l.json.token;
  const me = await call('GET', '/api/me', undefined, studentToken);
  assert.equal(me.json.user.role, 'student');
  assert.equal(me.json.user.isAdmin, false);
  assert.equal(me.json.profile.exam_target, 'BECE');
});

test('profile update + home countdown uses student-set date only', async () => {
  let h = await call('GET', '/api/home', undefined, studentToken);
  assert.equal(h.json.daysToExam, null);
  const future = new Date(Date.now() + 10 * 864e5).toISOString().slice(0, 10);
  assert.equal((await call('PATCH', '/api/me/profile', { examDate: future, dailyGoalMinutes: 45 }, studentToken)).status, 200);
  h = await call('GET', '/api/home', undefined, studentToken);
  assert.ok(h.json.daysToExam >= 9 && h.json.daysToExam <= 11);
  assert.equal(h.json.dailyGoalMinutes, 45);
  assert.equal(h.json.examTarget, 'BECE'); // untouched fields are preserved
  assert.deepEqual(h.json.weakTopics, []);
});

test('unauthenticated and non-admin access is refused server-side', async () => {
  assert.equal((await call('GET', '/api/home')).status, 401);
  assert.equal((await call('GET', '/api/admin/users', undefined, studentToken)).status, 403);
});

test('requested teacher role grants nothing until verified', async () => {
  assert.equal((await call('POST', '/api/me/verification-request', { role: 'teacher' }, studentToken)).status, 200);
  const me = await call('GET', '/api/me', undefined, studentToken);
  assert.equal(me.json.user.verificationStatus, 'pending');
  assert.equal((await call('POST', '/api/me/verification-request', { role: 'admin' }, studentToken)).status, 400);
});

test('admin can list, verify, deactivate; actions are audited', async () => {
  db.prepare(`INSERT INTO users (id, username, password_hash, display_name, role, verification_status) VALUES (?,?,?,?,'admin','verified')`)
    .run(randomUUID(), 'root', hashPassword('adminpass12345'), 'Root');
  adminToken = (await call('POST', '/api/auth/login', { username: 'root', password: 'adminpass12345' })).json.token;
  const stats = await call('GET', '/api/admin/stats', undefined, adminToken);
  assert.equal(stats.json.pendingVerifications, 1);
  const list = await call('GET', '/api/admin/users?pending=1', undefined, adminToken);
  const ama = list.json.users[0];
  assert.equal(ama.username, 'ama_k');
  assert.equal((await call('PATCH', `/api/admin/users/${ama.id}`, { verificationStatus: 'verified' }, adminToken)).status, 200);
  assert.equal((await call('PATCH', `/api/admin/users/${ama.id}`, { isActive: false }, adminToken)).status, 200);
  assert.equal((await call('GET', '/api/me', undefined, studentToken)).status, 401); // sessions revoked
  const auditLog = await call('GET', '/api/admin/audit', undefined, adminToken);
  const actions = auditLog.json.entries.map((e: any) => e.action);
  assert.ok(actions.includes('admin.user_update') && actions.includes('user.verification_requested') && actions.includes('user.register'));
});

test('admin cannot demote self', async () => {
  const me = await call('GET', '/api/me', undefined, adminToken);
  assert.equal((await call('PATCH', `/api/admin/users/${me.json.user.id}`, { role: 'student' }, adminToken)).status, 400);
});

test('self-delete removes the account', async () => {
  const t = (await call('POST', '/api/auth/register', { username: 'kofi', password: 'goodpass123', displayName: 'Kofi' })).json.token;
  assert.equal((await call('DELETE', '/api/me', undefined, t)).status, 200);
  assert.equal((await call('POST', '/api/auth/login', { username: 'kofi', password: 'goodpass123' })).status, 401);
});

test('unknown routes and bad JSON', async () => {
  assert.equal((await call('GET', '/api/nope')).status, 404);
  const r = await fetch(base + '/api/auth/login', { method: 'POST', body: '{bad' });
  assert.equal(r.status, 400);
});
