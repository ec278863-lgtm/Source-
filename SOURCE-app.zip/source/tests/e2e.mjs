// Browser smoke test: node tests/e2e.mjs <baseUrl> <outDir>
// Signs up a student, checks key screens on mobile and desktop, verifies admin gating.
import { chromium } from 'playwright';

const [base = 'http://127.0.0.1:8080', out = '/tmp/shots'] = process.argv.slice(2);
const browser = await chromium.launch();
const errors = [];
const check = (cond, msg) => { if (!cond) errors.push(msg); };

const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, colorScheme: 'dark' });
mobile.on('pageerror', e => errors.push('page error: ' + e.message));
await mobile.goto(base);
await mobile.waitForTimeout(500); await mobile.screenshot({ path: `${out}/1-signup.png` });
await mobile.fill('#dn', 'Akosua');
await mobile.fill('#un', 'akosua' + Date.now() % 10000);
await mobile.fill('#pw', 'studyhard123');
await mobile.click('button.btn.primary');
await mobile.waitForSelector('text=What do you want to understand today?');
check(await mobile.isVisible('text=Akosua'), 'greeting missing');
check(!(await mobile.isVisible('text=Admin')), 'admin link visible to student');
await mobile.waitForTimeout(500); await mobile.screenshot({ path: `${out}/2-home-mobile-dark.png`, fullPage: true });

await mobile.goto(base + '/#/settings');
await mobile.fill('#s-ed', new Date(Date.now() + 200 * 864e5).toISOString().slice(0, 10));
await mobile.click('text=Save changes');
await mobile.waitForSelector('text=Saved.');
await mobile.click('text=Light mode');
await mobile.goto(base + '/#/home');
await mobile.waitForSelector('text=days left');
await mobile.waitForTimeout(500); await mobile.screenshot({ path: `${out}/3-home-mobile-light.png`, fullPage: true });

await mobile.goto(base + '/#/admin'); // student forced back to Home
await mobile.waitForSelector('text=What do you want to understand today?');

const desk = await browser.newPage({ viewport: { width: 1360, height: 860 } });
desk.on('pageerror', e => errors.push('page error: ' + e.message));
await desk.goto(base);
await desk.click('text=Sign in');
await desk.fill('#un', 'admin');
await desk.fill('#pw', 'admin-pass-2026');
await desk.click('button.btn.primary');
await desk.waitForSelector('text=Admin');
await desk.goto(base + '/#/admin');
await desk.waitForSelector('text=SOURCE console');
await desk.waitForTimeout(500); await desk.screenshot({ path: `${out}/4-admin-desktop.png` });
await desk.goto(base + '/#/exams');
await desk.waitForSelector('text=BECE & WASSCE practice');
await desk.waitForTimeout(500); await desk.screenshot({ path: `${out}/5-exams-desktop.png` });

await browser.close();
if (errors.length) { console.error('E2E FAILED:\n' + errors.join('\n')); process.exit(1); }
console.log('E2E OK');
