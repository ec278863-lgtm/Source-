// Static (GitHub Pages) mode: same endpoints as the server, stored in this browser only.
// No admin here: admin rights can't be secured without a server.
import { ApiError } from './api';

const KEY = 'source.local.v1';
const SUBJECTS = ['English Language', 'Mathematics', 'Integrated Science', 'Social Studies', 'Biology', 'Chemistry', 'Physics',
  'Economics', 'Geography', 'Government', 'Financial Accounting', 'Literature in English', 'ICT'];

interface LocalUser { id: string; username: string; pw: string; displayName: string; profile: Record<string, any>; attempts: { t: string; s: number }[] }
interface Store { users: Record<string, LocalUser>; sessions: Record<string, string> }

const load = (): Store => { try { return JSON.parse(localStorage.getItem(KEY) || '') } catch { return { users: {}, sessions: {} }; } };
const save = (s: Store) => localStorage.setItem(KEY, JSON.stringify(s));
const rid = () => (crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now().toString(36));

async function hash(pw: string, salt: string) {
  const data = new TextEncoder().encode(salt + ':' + pw);
  if (crypto.subtle) return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', data))).map(b => b.toString(16).padStart(2, '0')).join('');
  let h = 0; for (const b of data) h = (h * 31 + b) | 0; return 'w' + h; // very old browsers only
}

const fail = (status: number, msg: string): never => { throw new ApiError(status, msg); };

export async function localApi(path: string, method: string, body: any, token: string | null): Promise<any> {
  const s = load();
  const user = token ? s.users[s.sessions[token]] : undefined;
  const need = () => user ?? fail(401, 'Please sign in.');
  const newSession = (id: string) => { const t = rid(); s.sessions[t] = id; save(s); return { token: t }; };
  const key = `${method} ${path.split('?')[0]}`;

  switch (key) {
    case 'POST /auth/register': {
      const username = String(body?.username ?? '').trim().toLowerCase();
      if (!/^[a-z0-9_.]{3,30}$/.test(username)) fail(400, 'Username: use 3–30 letters, numbers, dots or underscores.');
      if (String(body?.password ?? '').length < 8) fail(400, 'Password must be at least 8 characters.');
      if (!String(body?.displayName ?? '').trim()) fail(400, 'Please enter your name.');
      if (Object.values(s.users).some(u => u.username === username)) fail(409, 'That username is taken on this device.');
      const id = rid();
      s.users[id] = { id, username, pw: await hash(body.password, id), displayName: body.displayName.trim().slice(0, 40),
        profile: { class_level: null, exam_target: body.examTarget ?? null, exam_date: null, daily_goal_minutes: 30 }, attempts: [] };
      return newSession(id);
    }
    case 'POST /auth/login': {
      const u = Object.values(s.users).find(u => u.username === String(body?.username ?? '').trim().toLowerCase());
      if (!u || u.pw !== await hash(String(body?.password ?? ''), u.id)) fail(401, 'Wrong username or password.');
      return newSession(u!.id);
    }
    case 'POST /auth/logout': if (token) { delete s.sessions[token]; save(s); } return { ok: true };
    case 'GET /me': {
      const u = need();
      return { user: { id: u.id, username: u.username, displayName: u.displayName, role: 'student', verificationStatus: 'not_required', isAdmin: false }, profile: u.profile };
    }
    case 'PATCH /me/profile': {
      const u = need();
      if (body.displayName) u.displayName = String(body.displayName).trim().slice(0, 40);
      const map: Record<string, string> = { classLevel: 'class_level', examTarget: 'exam_target', examDate: 'exam_date', dailyGoalMinutes: 'daily_goal_minutes' };
      for (const [k, col] of Object.entries(map)) if (body[k] !== undefined) u.profile[col] = body[k];
      save(s); return { profile: u.profile };
    }
    case 'DELETE /me': {
      const u = need();
      delete s.users[u.id];
      for (const [t, id] of Object.entries(s.sessions)) if (id === u.id) delete s.sessions[t];
      save(s); return { ok: true };
    }
    case 'GET /home': {
      const u = need();
      const today = new Date().toISOString().slice(0, 10);
      const secs = u.attempts.filter(a => a.t >= today).reduce((n, a) => n + a.s, 0);
      const d = u.profile.exam_date;
      return { displayName: u.displayName, examTarget: u.profile.exam_target, examDate: d,
        daysToExam: d ? Math.ceil((Date.parse(d) - Date.parse(today)) / 864e5) : null,
        minutesToday: Math.round(secs / 60), dailyGoalMinutes: u.profile.daily_goal_minutes, weakTopics: [], verifiedQuestions: 0 };
    }
    case 'GET /subjects': return { subjects: SUBJECTS.map(n => ({ id: n, slug: n, name: n })) };
    default: return fail(path.startsWith('/admin') ? 403 : 404, path.startsWith('/admin') ? 'Admin needs the server version.' : 'Not found.');
  }
}
