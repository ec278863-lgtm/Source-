import type { ReactNode, CSSProperties } from 'react';
import { LuCircleAlert } from 'react-icons/lu';

export function Tile({ icon, title, text, tone, onClick, soon }: { icon: ReactNode; title: string; text: string; tone?: string; onClick?: () => void; soon?: string }) {
  return (
    <button className="card tile" onClick={soon ? undefined : onClick} aria-disabled={soon ? true : undefined} style={{ '--tone': tone } as CSSProperties}>
      <span className="icon-badge">{icon}</span>
      <span className="stack" style={{ gap: 2 }}>
        <span className="row" style={{ gap: 8 }}><h3>{title}</h3>{soon && <span className="chip">{soon}</span>}</span>
        <span className="muted small">{text}</span>
      </span>
    </button>
  );
}

export function Empty({ icon, title, text, action }: { icon?: ReactNode; title: string; text: string; action?: ReactNode }) {
  return (
    <div className="empty">
      {icon}
      <h3 style={{ color: 'var(--text)' }}>{title}</h3>
      <p className="small" style={{ margin: '4px auto 12px', maxWidth: 340 }}>{text}</p>
      {action}
    </div>
  );
}

export function ErrorState({ message, retry }: { message: string; retry?: () => void }) {
  return (
    <div className="card">
      <Empty icon={<LuCircleAlert />} title="Couldn't load this" text={message} action={retry && <button className="btn" onClick={retry}>Try again</button>} />
    </div>
  );
}

export function Ring({ percent, label }: { percent: number; label: string }) {
  return <div className="ring" style={{ '--p': Math.min(100, Math.max(0, percent)) } as CSSProperties} role="img" aria-label={`${Math.round(percent)}% of daily goal`}><span>{label}</span></div>;
}

export function PageHeader({ eyebrow, title, text }: { eyebrow?: string; title: string; text?: string }) {
  return (
    <header className="stack" style={{ gap: 4, marginBottom: 8 }}>
      {eyebrow && <span className="eyebrow">{eyebrow}</span>}
      <h1>{title}</h1>
      {text && <p className="muted" style={{ margin: 0 }}>{text}</p>}
    </header>
  );
}
