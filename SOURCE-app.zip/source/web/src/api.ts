declare const __STATIC__: boolean; // true in the single-file GitHub Pages build
const TOKEN_KEY = 'source.token';

export const auth = {
  get: () => { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } },
  set: (t: string | null) => { try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch { /* storage unavailable */ } },
};

export class ApiError extends Error { constructor(public status: number, message: string) { super(message); } }

export async function api<T = any>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  const token = auth.get();
  if (__STATIC__) {
    const { localApi } = await import('./localApi');
    try { return await localApi(path, opts.method ?? 'GET', opts.body, token); }
    catch (e) { if ((e as ApiError).status === 401 && token) { auth.set(null); window.dispatchEvent(new Event('source:signed-out')); } throw e; }
  }
  let res: Response;
  try {
    res = await fetch('/api' + path, {
      method: opts.method ?? 'GET',
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
    });
  } catch {
    throw new ApiError(0, "You're offline. Check your connection and try again.");
  }
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && token) { auth.set(null); window.dispatchEvent(new Event('source:signed-out')); }
  if (!res.ok) throw new ApiError(res.status, data.error ?? 'Something went wrong.');
  return data as T;
}

export interface Me {
  user: { id: string; username: string; displayName: string; role: string; verificationStatus: string; isAdmin: boolean };
  profile: { class_level: string | null; exam_target: string | null; exam_date: string | null; daily_goal_minutes: number } | null;
}
