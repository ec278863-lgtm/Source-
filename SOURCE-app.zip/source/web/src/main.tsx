import { createRoot } from 'react-dom/client';
import { App } from './App';

// Theme: saved choice, else the device setting.
const saved = (() => { try { return localStorage.getItem('source.theme'); } catch { return null; } })();
document.documentElement.dataset.theme = saved ?? (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark');

createRoot(document.getElementById('root')!).render(<App />);
