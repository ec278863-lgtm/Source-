import { useState, type FormEvent } from 'react';
import { LuMoon, LuSun, LuLogOut } from 'react-icons/lu';
import { api, auth, type Me } from '../api';
import { PageHeader } from '../ui';

export function Settings({ me, onChange }: { me: Me; onChange: () => void }) {
  const p = me.profile;
  const [f, setF] = useState({
    displayName: me.user.displayName, classLevel: p?.class_level ?? '', examTarget: p?.exam_target ?? '',
    examDate: p?.exam_date ?? '', dailyGoalMinutes: p?.daily_goal_minutes ?? 30,
  });
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [theme, setTheme] = useState(document.documentElement.dataset.theme);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: k === 'dailyGoalMinutes' ? Number(e.target.value) : e.target.value });

  async function save(e: FormEvent) {
    e.preventDefault(); setMsg(null);
    try {
      await api('/me/profile', { method: 'PATCH', body: { ...f, classLevel: f.classLevel || null, examTarget: f.examTarget || null, examDate: f.examDate || null } });
      setMsg({ ok: true, text: 'Saved.' }); onChange();
    } catch (err) { setMsg({ ok: false, text: (err as Error).message }); }
  }
  function toggleTheme() {
    const t = theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = t; setTheme(t);
    try { localStorage.setItem('source.theme', t); } catch { /* ignore */ }
  }
  async function signOut() { await api('/auth/logout', { method: 'POST' }).catch(() => {}); auth.set(null); location.hash = ''; location.reload(); }
  async function deleteAccount() {
    if (!confirm('Delete your account and all your progress? This cannot be undone.')) return;
    await api('/me', { method: 'DELETE' }); auth.set(null); location.hash = ''; location.reload();
  }

  return (
    <div className="stack" style={{ gap: 20, maxWidth: 560 }}>
      <PageHeader eyebrow="Settings" title="Your profile" />
      <form className="card pad-lg stack" onSubmit={save}>
        <div className="field"><label htmlFor="s-dn">Name</label><input id="s-dn" className="input" value={f.displayName} onChange={set('displayName')} maxLength={40} required /></div>
        <div className="grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <div className="field"><label htmlFor="s-cl">Class</label>
            <select id="s-cl" className="input" value={f.classLevel} onChange={set('classLevel')}>
              <option value="">Not set</option>{['JHS1', 'JHS2', 'JHS3', 'SHS1', 'SHS2', 'SHS3'].map(c => <option key={c}>{c}</option>)}
            </select></div>
          <div className="field"><label htmlFor="s-ex">Exam</label>
            <select id="s-ex" className="input" value={f.examTarget} onChange={set('examTarget')}>
              <option value="">Not set</option><option>BECE</option><option>WASSCE</option>
            </select></div>
        </div>
        <div className="field"><label htmlFor="s-ed">Exam start date</label>
          <input id="s-ed" type="date" className="input" value={f.examDate} onChange={set('examDate')} />
          <span className="muted small">Use the date on your official timetable from WAEC or your school.</span></div>
        <div className="field"><label htmlFor="s-goal">Daily study goal: {f.dailyGoalMinutes} min</label>
          <input id="s-goal" type="range" min={10} max={240} step={5} value={f.dailyGoalMinutes} onChange={set('dailyGoalMinutes')} /></div>
        {msg && <p className={msg.ok ? 'small' : 'error'} role="status" style={{ margin: 0, color: msg.ok ? 'var(--green)' : undefined }}>{msg.text}</p>}
        <button className="btn primary">Save changes</button>
      </form>

      <section className="card stack">
        <div className="row spread"><span>Appearance</span>
          <button className="btn" onClick={toggleTheme}>{theme === 'dark' ? <><LuSun /> Light mode</> : <><LuMoon /> Dark mode</>}</button></div>
        <div className="row spread"><span className="muted small">Signed in as @{me.user.username}</span>
          <button className="btn ghost" onClick={signOut}><LuLogOut /> Sign out</button></div>
      </section>

      <section className="card stack">
        <h3>Your data</h3>
        <p className="muted small" style={{ margin: 0 }}>SOURCE stores only what it needs to teach you: your username, name, class, exam and practice history. You can delete everything at any time.</p>
        <div><button className="btn danger" onClick={deleteAccount}>Delete my account</button></div>
      </section>
    </div>
  );
}
