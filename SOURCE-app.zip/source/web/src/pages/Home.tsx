import { useEffect, useState, type CSSProperties } from 'react';
import { LuSparkles, LuArrowRight, LuTarget, LuCalendarDays, LuFlame, LuScanLine, LuTimer, LuMegaphone } from 'react-icons/lu';
import { api } from '../api';
import { Empty, ErrorState, Ring, Tile } from '../ui';
import type { Route } from '../App';

interface HomeData {
  displayName: string; examTarget: string | null; examDate: string | null; daysToExam: number | null;
  minutesToday: number; dailyGoalMinutes: number; weakTopics: { id: string; name: string; accuracy: number }[]; verifiedQuestions: number;
}

const greeting = () => { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; };

export function Home({ go }: { go: (r: Route) => void }) {
  const [d, setD] = useState<HomeData | null>(null);
  const [err, setErr] = useState('');
  const load = () => { setErr(''); api<HomeData>('/home').then(setD).catch(e => setErr(e.message)); };
  useEffect(load, []);

  if (err) return <ErrorState message={err} retry={load} />;
  if (!d) return <div className="stack"><div className="skeleton" style={{ minHeight: 150 }} /><div className="grid"><div className="skeleton" /><div className="skeleton" /></div></div>;

  const pct = (d.minutesToday / d.dailyGoalMinutes) * 100;

  return (
    <div className="stack" style={{ gap: 20 }}>
      <header className="stack" style={{ gap: 2 }}>
        <span className="muted">{greeting()},</span>
        <h1>{d.displayName}</h1>
      </header>

      {/* AI Teacher — the main action */}
      <section className="card hero pad-lg stack">
        <span className="row" style={{ gap: 8 }}><LuSparkles style={{ color: 'var(--cyan)' }} /><span className="eyebrow" style={{ color: '#B9C4D6' }}>SOURCE Teacher</span></span>
        <h2 style={{ fontSize: 22 }}>What do you want to understand today?</h2>
        <p className="muted" style={{ margin: 0 }}>Ask about any topic. Get it explained simply, step by step, with Ghanaian examples.</p>
        <div><button className="btn primary" onClick={() => go('learn')}>Ask the Teacher <LuArrowRight /></button></div>
      </section>

      <div className="grid">
        {/* Daily progress */}
        <section className="card row" style={{ gap: 16 }}>
          <Ring percent={pct} label={`${d.minutesToday}m`} />
          <div className="stack" style={{ gap: 2 }}>
            <span className="eyebrow">Today</span>
            <h3>{d.minutesToday >= d.dailyGoalMinutes ? 'Daily goal reached' : `${d.dailyGoalMinutes - d.minutesToday} min to your goal`}</h3>
            <span className="muted small">Goal: {d.dailyGoalMinutes} minutes a day</span>
          </div>
        </section>

        {/* Exam countdown — only from the date the student sets */}
        <section className="card row" style={{ gap: 16 }}>
          <span className="icon-badge" style={{ '--tone': 'var(--gold)' } as CSSProperties}><LuCalendarDays /></span>
          {d.daysToExam !== null && d.daysToExam >= 0 ? (
            <div className="stack" style={{ gap: 0 }}>
              <span className="eyebrow">{d.examTarget ?? 'Exam'} countdown</span>
              <span className="stat">{d.daysToExam} <span className="small muted" style={{ fontWeight: 600 }}>days left</span></span>
            </div>
          ) : (
            <div className="stack" style={{ gap: 4 }}>
              <span className="eyebrow">{d.examTarget ?? 'Exam'} countdown</span>
              <span className="small muted">Add your exam date to see your countdown and plan.</span>
              <button className="btn" style={{ minHeight: 36, justifySelf: 'start' }} onClick={() => go('settings')}>Set exam date</button>
            </div>
          )}
        </section>
      </div>

      {/* Weak topics / recommendations */}
      <section className="card stack">
        <div className="row spread"><h2>Focus next</h2><LuTarget className="muted" /></div>
        {d.weakTopics.length ? d.weakTopics.map(t => (
          <div key={t.id} className="row spread">
            <span>{t.name}</span><span className="chip gold">{Math.round(t.accuracy * 100)}% correct</span>
          </div>
        )) : (
          <Empty icon={<LuFlame />} title="Your study plan starts with practice"
            text="Answer a few questions and SOURCE will show the topics you need most, and why." />
        )}
      </section>

      <section className="stack">
        <h2>Quick tools</h2>
        <div className="grid">
          <Tile icon={<LuScanLine />} title="Scan a question" text="Snap a question and get it explained." soon="Soon" />
          <Tile icon={<LuTimer />} tone="var(--royal)" title="Focus session" text="A timed study session with breaks." soon="Soon" />
          <Tile icon={<LuMegaphone />} tone="var(--gold)" title="School updates" text="Events and news from schools you follow." onClick={() => go('campus')} />
        </div>
      </section>
    </div>
  );
}
