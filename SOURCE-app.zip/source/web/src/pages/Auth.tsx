import { useState, type FormEvent } from 'react';
import { api, auth } from '../api';

export function AuthScreen({ onSignedIn }: { onSignedIn: () => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [f, setF] = useState({ username: '', password: '', displayName: '', examTarget: 'BECE' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      const body = mode === 'login' ? { username: f.username, password: f.password } : f;
      const { token } = await api<{ token: string }>(`/auth/${mode}`, { method: 'POST', body });
      auth.set(token);
      onSignedIn();
    } catch (err) { setError((err as Error).message); }
    finally { setBusy(false); }
  }

  return (
    <div className="auth">
      <div className="stack" style={{ width: 'min(420px, 100%)', gap: 20 }}>
        <div className="stack" style={{ gap: 6, textAlign: 'center', justifyItems: 'center' }}>
          <div className="brand" style={{ fontSize: 18 }}><img src="/icon.svg" alt="" />SOURCE</div>
          <p className="muted" style={{ margin: 0 }}>Don't just study. Understand.</p>
        </div>
        <form className="card pad-lg stack" onSubmit={submit}>
          <div className="tabs" role="tablist">
            <button type="button" role="tab" aria-selected={mode === 'register'} onClick={() => setMode('register')}>Create account</button>
            <button type="button" role="tab" aria-selected={mode === 'login'} onClick={() => setMode('login')}>Sign in</button>
          </div>
          {mode === 'register' && (
            <div className="field"><label htmlFor="dn">What should we call you?</label>
              <input id="dn" className="input" value={f.displayName} onChange={set('displayName')} maxLength={40} required autoComplete="nickname" /></div>
          )}
          <div className="field"><label htmlFor="un">Username</label>
            <input id="un" className="input" value={f.username} onChange={set('username')} required autoComplete="username" autoCapitalize="none" /></div>
          <div className="field"><label htmlFor="pw">Password</label>
            <input id="pw" type="password" className="input" value={f.password} onChange={set('password')} required minLength={mode === 'register' ? 8 : 1}
              autoComplete={mode === 'register' ? 'new-password' : 'current-password'} /></div>
          {mode === 'register' && (
            <div className="field"><label htmlFor="ex">I'm preparing for</label>
              <select id="ex" className="input" value={f.examTarget} onChange={set('examTarget')}>
                <option value="BECE">BECE (JHS)</option><option value="WASSCE">WASSCE (SHS)</option>
              </select></div>
          )}
          {error && <p className="error" role="alert" style={{ margin: 0 }}>{error}</p>}
          <button className="btn primary" disabled={busy}>{busy ? 'Please wait…' : mode === 'register' ? 'Start learning' : 'Sign in'}</button>
          {mode === 'register' && <p className="muted small" style={{ margin: 0 }}>No email or phone number needed. Just a username and password.</p>}
        </form>
      </div>
    </div>
  );
}
