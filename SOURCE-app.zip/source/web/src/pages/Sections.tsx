// Section hubs. Each shows its tools with progressive disclosure; tools not yet built say so
// honestly instead of showing placeholder data.
import { useEffect, useState } from 'react';
import { LuBookOpen, LuSparkles, LuFlaskConical, LuScanLine, LuGraduationCap, LuTrendingUp, LuTarget, LuSearch, LuSchool,
  LuTrophy, LuCalendarDays, LuMegaphone, LuUsers, LuRadar, LuChartLine, LuFlame } from 'react-icons/lu';
import { api } from '../api';
import { Empty, ErrorState, PageHeader, Tile } from '../ui';
import type { Route } from '../App';

export function Learn() {
  const [subjects, setSubjects] = useState<{ id: string; name: string }[] | null>(null);
  const [err, setErr] = useState('');
  const load = () => { setErr(''); api('/subjects').then(r => setSubjects(r.subjects)).catch(e => setErr(e.message)); };
  useEffect(load, []);
  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHeader eyebrow="Learn" title="Understand any topic" text="Pick a subject, or ask the Teacher directly." />
      <div className="grid">
        <Tile icon={<LuSparkles />} title="SOURCE Teacher" text="Explanations that get simpler until it clicks: six levels, including Caveman Mode." soon="Stage 3" />
        <Tile icon={<LuFlaskConical />} tone="var(--royal)" title="Visual Lab" text="Diagrams, animations and simulations." soon="Stage 4" />
        <Tile icon={<LuScanLine />} tone="var(--gold)" title="Scanner" text="Turn photos of notes into summaries and flashcards." soon="Stage 6" />
      </div>
      <section className="stack">
        <h2>Subjects</h2>
        {err ? <ErrorState message={err} retry={load} /> : !subjects ? <div className="skeleton" /> : (
          <div className="grid">{subjects.map(s => <Tile key={s.id} icon={<LuBookOpen />} title={s.name} text="Lessons arrive as the curriculum is verified." soon="Soon" />)}</div>
        )}
      </section>
    </div>
  );
}

export function Exams() {
  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHeader eyebrow="Exams" title="BECE & WASSCE practice" text="Every past question will show its year, paper and source, so you know it's real." />
      <div className="grid">
        <Tile icon={<LuGraduationCap />} title="Past questions" text="Verified past papers with explanations of every option." soon="Stage 2" />
        <Tile icon={<LuTarget />} tone="var(--green)" title="Mock exams" text="Timed papers marked against official schemes." soon="Stage 6" />
        <Tile icon={<LuTrendingUp />} tone="var(--gold)" title="Predict" text="Revision priorities backed by evidence and tested on past years. Never guesses." soon="Stage 5" />
      </div>
    </div>
  );
}

export function Schools() {
  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHeader eyebrow="Schools" title="Find and compare schools" text="Verified categories, programmes and admission information, with sources." />
      <div className="card row" aria-disabled="true" style={{ opacity: .7 }}><LuSearch className="muted" /><span className="muted">Search schools by name, region or programme</span></div>
      <div className="card">
        <Empty icon={<LuSchool />} title="School Finder is coming in Stage 7"
          text="We'll only list schools and categories from current official lists, each with its source and effective date." />
      </div>
    </div>
  );
}

export function Campus() {
  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHeader eyebrow="Campus" title="What's happening across schools" text="Competitions, events, SRC news and study groups." />
      <div className="grid">
        <Tile icon={<LuTrophy />} tone="var(--gold)" title="Competitions" text="Quiz contests, sports, debates. Verified results only." soon="Stage 8" />
        <Tile icon={<LuCalendarDays />} title="Events" text="Calendars and reminders from schools you follow." soon="Stage 8" />
        <Tile icon={<LuMegaphone />} tone="var(--royal)" title="SRC" text="Official announcements from verified SRC officers." soon="Stage 8" />
        <Tile icon={<LuUsers />} tone="var(--green)" title="Study groups" text="Moderated study rooms with students like you." soon="Stage 8" />
        <Tile icon={<LuRadar />} title="Radar" text="New resources, scholarships and exam announcements." soon="Stage 9" />
      </div>
    </div>
  );
}

export function Progress({ go }: { go: (r: Route) => void }) {
  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHeader eyebrow="My Progress" title="How you're doing" text="Mastery is measured with new questions, not memorised ones." />
      <div className="card">
        <Empty icon={<LuChartLine />} title="No practice yet"
          text="Your topic mastery, weak areas and exam readiness will appear here once you start practising."
          action={<button className="btn" onClick={() => go('exams')}>Go to Exams</button>} />
      </div>
      <div className="grid">
        <Tile icon={<LuFlame />} tone="var(--gold)" title="Revision schedule" text="Spaced repetition built from your weak topics." soon="Stage 6" />
        <Tile icon={<LuCalendarDays />} title="Study planner" text="Timetable, homework and deadlines." soon="Stage 6" />
      </div>
    </div>
  );
}
