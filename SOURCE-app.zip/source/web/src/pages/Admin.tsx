// Admin console. The UI hides it from non-admins, but every endpoint is enforced server-side.
import { useEffect, useState } from 'react';
import { api, type Me } from '../api';
import { ErrorState, PageHeader } from '../ui';

interface U { id: string; username: string; display_name: string; role: string; verification_status: string; is_active: number; created_at: string }
interface A { id: string; action: string; actor: string | null; target_type: string | null; created_at: string; details: string | null }
const ROLES = ['student', 'teacher', 'school_rep', 'src_officer', 'moderator', 'admin'];
const statusChip: Record<string, string> = { verified: 'green', pending: 'gold', rejected: '', not_required: '' };

export function Admin({ me }: { me: Me }) {
  const [tab, setTab] = useState<'users' | 'audit'>('users');
  const [stats, setStats] = useState<Record<string, number> | null>(null);
  const [users, setUsers] = useState<U[]>([]);
  const [audit, setAudit] = useState<A[]>([]);
  const [q, setQ] = useState('');
  const [pending, setPending] = useState(false);
  const [err, setErr] = useState('');

  const load = () => {
    setErr('');
    Promise.all([
      api('/admin/stats').then(setStats),
      api(`/admin/users?q=${encodeURIComponent(q)}${pending ? '&pending=1' : ''}`).then(r => setUsers(r.users)),
      api('/admin/audit').then(r => setAudit(r.entries)),
    ]).catch(e => setErr(e.message));
  };
  useEffect(load, [q, pending]);

  async function update(id: string, body: object) {
    try { await api(`/admin/users/${id}`, { method: 'PATCH', body }); load(); } catch (e) { alert((e as Error).message); }
  }

  if (err) return <ErrorState message={err} retry={load} />;
  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHeader eyebrow="Admin" title="SOURCE console" />
      <div className="grid">
        {stats && ([['Users', stats.users], ['Students', stats.students], ['Pending verification', stats.pendingVerifications], ['Verified questions', `${stats.verifiedQuestions} / ${stats.questions}`]] as const).map(([k, v]) => (
          <div key={k} className="card"><span className="eyebrow">{k}</span><div className="stat">{v}</div></div>
        ))}
      </div>
      <div className="tabs" style={{ maxWidth: 320 }} role="tablist">
        <button role="tab" aria-selected={tab === 'users'} onClick={() => setTab('users')}>Users</button>
        <button role="tab" aria-selected={tab === 'audit'} onClick={() => setTab('audit')}>Audit log</button>
      </div>
      {tab === 'users' ? (
        <section className="card stack">
          <div className="row" style={{ flexWrap: 'wrap' }}>
            <input className="input compact" placeholder="Search users" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1, minWidth: 180 }} />
            <label className="row small" style={{ gap: 6 }}><input type="checkbox" checked={pending} onChange={e => setPending(e.target.checked)} /> Pending only</label>
          </div>
          <div className="scroll-x"><table className="table">
            <thead><tr><th>User</th><th>Role</th><th>Verification</th><th>Status</th><th /></tr></thead>
            <tbody>{users.map(u => (
              <tr key={u.id}>
                <td><strong>{u.display_name}</strong><div className="muted small">@{u.username}</div></td>
                <td><select className="input compact" value={u.role} disabled={u.id === me.user.id} onChange={e => update(u.id, { role: e.target.value })}>{ROLES.map(r => <option key={r}>{r}</option>)}</select></td>
                <td><span className={`chip ${statusChip[u.verification_status]}`}>{u.verification_status.replace('_', ' ')}</span></td>
                <td>{u.is_active ? <span className="chip green">active</span> : <span className="chip">deactivated</span>}</td>
                <td><div className="row" style={{ gap: 6, justifyContent: 'flex-end' }}>
                  {u.verification_status === 'pending' && <>
                    <button className="btn" style={{ minHeight: 34 }} onClick={() => update(u.id, { verificationStatus: 'verified' })}>Verify</button>
                    <button className="btn ghost" style={{ minHeight: 34 }} onClick={() => update(u.id, { verificationStatus: 'rejected' })}>Reject</button></>}
                  {u.id !== me.user.id && <button className="btn ghost" style={{ minHeight: 34 }} onClick={() => update(u.id, { isActive: !u.is_active })}>{u.is_active ? 'Deactivate' : 'Reactivate'}</button>}
                </div></td>
              </tr>))}
            </tbody>
          </table></div>
        </section>
      ) : (
        <section className="card scroll-x">
          <table className="table">
            <thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Target</th></tr></thead>
            <tbody>{audit.map(a => (
              <tr key={a.id}><td className="small muted">{new Date(a.created_at.replace(' ', 'T') + (a.created_at.includes('Z') ? '' : 'Z')).toLocaleString()}</td>
                <td>{a.actor ?? 'system'}</td><td><code>{a.action}</code></td><td className="small muted">{a.target_type ?? ''}</td></tr>))}
            </tbody>
          </table>
        </section>
      )}
    </div>
  );
}
