import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { LuHouse, LuBookOpen, LuGraduationCap, LuSchool, LuUsers, LuChartLine, LuShieldCheck, LuSettings } from 'react-icons/lu';
import { api, auth, type Me } from './api';
import { AuthScreen } from './pages/Auth';
import { Home } from './pages/Home';
import { Learn, Exams, Schools, Campus, Progress } from './pages/Sections';
import { Settings } from './pages/Settings';
import { Admin } from './pages/Admin';

export type Route = 'home' | 'learn' | 'exams' | 'schools' | 'campus' | 'progress' | 'settings' | 'admin';
const NAV: [Route, string, ReactNode][] = [
  ['home', 'Home', <LuHouse />], ['learn', 'Learn', <LuBookOpen />], ['exams', 'Exams', <LuGraduationCap />],
  ['schools', 'Schools', <LuSchool />], ['campus', 'Campus', <LuUsers />], ['progress', 'Progress', <LuChartLine />],
];

const readRoute = (): Route => (location.hash.replace('#/', '') as Route) || 'home';

export function App() {
  const [me, setMe] = useState<Me | null>(null);
  const [booting, setBooting] = useState(!!auth.get());
  const [route, setRoute] = useState<Route>(readRoute);

  const loadMe = useCallback(() => {
    if (!auth.get()) { setMe(null); setBooting(false); return; }
    api<Me>('/me').then(setMe).catch(() => setMe(null)).finally(() => setBooting(false));
  }, []);

  useEffect(() => {
    loadMe();
    const onHash = () => { setRoute(readRoute()); window.scrollTo(0, 0); };
    const onOut = () => setMe(null);
    addEventListener('hashchange', onHash);
    addEventListener('source:signed-out', onOut);
    return () => { removeEventListener('hashchange', onHash); removeEventListener('source:signed-out', onOut); };
  }, [loadMe]);

  const go = (r: Route) => { location.hash = '#/' + r; };

  if (booting) return <div className="auth"><div className="skeleton" style={{ width: 200 }} /></div>;
  if (!me) return <AuthScreen onSignedIn={loadMe} />;

  const page = (() => {
    switch (route) {
      case 'learn': return <Learn />;
      case 'exams': return <Exams />;
      case 'schools': return <Schools />;
      case 'campus': return <Campus />;
      case 'progress': return <Progress go={go} />;
      case 'settings': return <Settings me={me} onChange={loadMe} />;
      case 'admin': return me.user.isAdmin ? <Admin me={me} /> : <Home go={go} />;
      default: return <Home go={go} />;
    }
  })();

  return (
    <div className="app">
      <nav className="nav" aria-label="Main">
        <div className="brand"><img src="/icon.svg" alt="" />SOURCE</div>
        {NAV.map(([r, label, icon]) => (
          <button key={r} className="nav-item" aria-current={route === r ? 'page' : undefined} onClick={() => go(r)}>{icon}<span>{label}</span></button>
        ))}
        <div className="nav-foot">
          {me.user.isAdmin && <button className="nav-item" aria-current={route === 'admin' ? 'page' : undefined} onClick={() => go('admin')}><LuShieldCheck /><span>Admin</span></button>}
          <button className="nav-item" aria-current={route === 'settings' ? 'page' : undefined} onClick={() => go('settings')}><LuSettings /><span>Settings</span></button>
        </div>
      </nav>
      <main className="main" key={route}>{page}</main>
    </div>
  );
}
