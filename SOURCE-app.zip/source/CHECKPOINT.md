# SOURCE — Project checkpoint

**Updated:** 2026-11-25 · **Stage:** 1 (Foundation), core complete

## Stack (decided)
- Frontend: React 19 + TypeScript, bundled by esbuild (`build.mjs`). Hand-written token CSS (`web/src/styles.css`), not Tailwind, because Tailwind wasn't installable in the build environment. Icons: react-icons/lu.
- Backend: Node 22 + TypeScript (run with tsx), built-in `node:http`, zod validation.
- DB: `node:sqlite` for dev. `db/migrations/*.sql` is written to run on both SQLite and PostgreSQL (verified on PG 16). Production target is PostgreSQL. Next step for that: add the `pg` driver behind the same queries.
- FastAPI was considered but not used: it couldn't be installed, and one TypeScript codebase is cheaper to maintain.

## Done (tested)
- Schema 001 has 15 tables: users, sessions, student_profiles, audit_logs, exams, subjects, exam_subjects, sources, syllabus_versions, topics, past_papers, questions (with provenance and verification status), question_options (`why_wrong`), question_dna, attempts.
- Auth: scrypt password hashes; opaque session tokens (only a SHA-256 hash is stored); logout; 30-day expiry; rate limits on login and register; no email or phone collected.
- Roles: student, teacher, school_rep, src_officer, moderator, admin. Elevated roles grant nothing until an admin verifies them, and this is enforced server-side (`hasRole`). Admins are created only from the CLI (`npm run create-admin`).
- Audit log covers register, verification requests, admin user changes and self-delete.
- Students can delete their own account (data cascades) and edit their profile.
- Home: greeting, Teacher hero, daily-goal ring, exam countdown (only from the student's own date), weak topics (from real attempts), quick tools.
- Section hubs for Learn, Exams, Schools, Campus and Progress. Unbuilt tools are labelled with their stage; no fake data.
- Admin console: stats, user search, pending filter, role changes, verify/reject, deactivate (revokes sessions), audit log.
- Dark and light themes; bottom nav on mobile, sidebar on desktop; structured JSON logs; security headers and CSP; SPA fallback.

## Tests
- `npm test`: 10/10 API tests pass (auth, validation, RBAC, verification gating, audit, self-delete, errors).
- `node tests/e2e.mjs`: browser smoke test passes on mobile (390px) and desktop; admin route stays gated for students.
- `npm run typecheck`: server passes. Frontend typecheck is pending until `@types/react` is installed.

## Outstanding
- Parental/guardian consent flow (the `guardian_consent` column exists). Needs review against Ghana's Data Protection Act (Act 843) before launch.
- Self-host the Manrope font (currently falls back to system fonts).
- PostgreSQL runtime driver, backups, CI (GitHub Actions).
- Subject↔exam mapping and syllabus versions are not seeded. They must come from official NaCCA/WAEC documents (Stage 2).
- Students can't yet request teacher/SRC verification from the UI; the API endpoint exists.

## Next actions (in order)
1. Stage 2: admin CRUD for sources, syllabus versions, topics, past papers and questions, with provenance required and a verification workflow.
2. Question practice UI (MCQ with explanations of wrong options) that writes `attempts`, which drives weak topics and progress.
3. AI gateway (provider-independent routing, usage logs, budgets), then SOURCE Teacher + Caveman Mode (Stage 3).

## Static build (GitHub Pages)
- `node build-static.mjs` writes one self-contained `docs/index.html`. Accounts and progress are saved in the browser (localStorage), and there is no admin. Tested: signup, login, profile, persistence after reload, sign-out.

## Android
- Installable PWA (manifest + offline service worker in docs/): tested install manifest, service worker control and offline reload.
- `.github/workflows/android.yml` builds a debug APK with Capacitor 7 (Java 21) and deploys Pages. NOT yet run: it needs GitHub. Next: confirm the first run, then add a signed release build for the Play Store.

## Run
```
npm run build && npm run create-admin -- admin <12+ char password> && npm start   # http://localhost:8080
```
