# SOURCE — Master roadmap

Status: ✅ done · 🟡 in progress · ⬜ not started. Classification follows the brief: E = Essential, H = High Value, O = Optional.

| Stage | Scope | Status |
|---|---|---|
| 1 Foundation | Auth, DB schema, design system, student dashboard, admin console, logging | ✅ core (consent flow, PG driver and CI outstanding) |
| 2 Exam knowledge base (E) | Sources, syllabus versions, topics, past papers, questions, Question DNA, marking schemes, provenance and verification workflow, practice UI | ⬜ next |
| 3 AI learning (E) | AI gateway (routing, fallback, budgets, usage logs), SOURCE Teacher, Caveman Mode 6 levels, learning memory | ⬜ |
| 4 Visual Lab (H) | SVG/Canvas/KaTeX first; Manim/Remotion only for cached, reusable lessons | ⬜ |
| 5 Exam intelligence (H) | Topic recurrence, evidence-based priorities (Strong/Moderate/Additional/Insufficient), backtesting | ⬜ |
| 6 Assessment (E) | Scanner/OCR, scheme-grounded Examiner, mocks, spaced repetition, planner, offline packs + sync | ⬜ |
| 7 Schools & curriculum (H) | Verified school lists/categories with sources and dates, compare ≤4, recommendations (no guarantees) | ⬜ |
| 8 Campus (O→H) | Events, competitions (verified results only), SRC with approval workflow, clubs, moderated study groups | ⬜ |
| 9 Radar (O) | Authorised-source discovery pipeline, verification states, notifications | ⬜ |
| 10 Launch | Security review, low-end Android performance, accessibility, student and teacher testing, Capacitor build | ⬜ |

Principles: never fabricate data, predictions, results or school information; build simply on screen with progressive disclosure; keep it cheap to run.
