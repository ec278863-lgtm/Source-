import { openDb } from './db.ts';
import { createApp } from './app.ts';
import { log } from './log.ts';

const port = Number(process.env.PORT ?? 8080);
const db = openDb(process.env.DB_FILE ?? 'data/source.db');
createApp(db).listen(port, () => log.info('SOURCE listening', { port }));
