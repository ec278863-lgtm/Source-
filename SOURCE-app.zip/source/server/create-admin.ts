// Usage: npm run create-admin -- <username> <password> "<Display Name>"
// Admins are only created from the server console, never through the public API.
import { randomUUID } from 'node:crypto';
import { openDb } from './db.ts';
import { hashPassword } from './auth.ts';

const [username, password, displayName = 'Administrator'] = process.argv.slice(2);
if (!username || !password || password.length < 12) {
  console.error('Usage: create-admin <username> <password (12+ chars)> [display name]');
  process.exit(1);
}
const db = openDb(process.env.DB_FILE ?? 'data/source.db');
const id = randomUUID();
db.prepare(`INSERT INTO users (id, username, password_hash, display_name, role, verification_status) VALUES (?,?,?,?, 'admin', 'verified')`)
  .run(id, username.toLowerCase(), hashPassword(password), displayName);
db.prepare(`INSERT INTO audit_logs (id, actor_id, action, target_type, target_id) VALUES (?,?,?,?,?)`).run(randomUUID(), null, 'admin.created_via_cli', 'user', id);
console.log(`Admin "${username}" created.`);
