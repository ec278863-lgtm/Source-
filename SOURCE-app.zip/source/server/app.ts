import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { join, extname, normalize } from 'node:path';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import type { DB } from './db.ts';
import { log } from './log.ts';
import { ROLES, createSession, deleteSession, hashPassword, hasRole, userFromToken, verifyPassword, type User } from './auth.ts';

class HttpError extends Error { constructor(public status: number, message: string) { super(message); } }
type Ctx = { req: IncomingMessage; res: ServerResponse; db: DB; params: Record<string, string>; body: any; user: User | null; ip: string; url: URL };
type Handler = (c: Ctx) => unknown | Promise<unknown>;

const STATIC_DIR = join(import.meta.dirname, '..', 'web', 'dist');
const MIME: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.json': 'application/json', '.png': 'image/png', '.woff2': 'font/woff2' };
const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'DENY',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'",
};

// ---- small helpers -------------------------------------------------------
const rateBuckets = new Map<string, { n: number; reset: number }>();
function rateLimit(key: string, max: number, windowMs: number) {
  const now = Date.now();
  const b = rateBuckets.get(key);
  if (!b || b.reset < now) { rateBuckets.set(key, { n: 1, reset: now + windowMs }); return; }
  if (++b.n > max) throw new HttpError(429, 'Too many attempts. Please wait a minute and try again.');
}
function parse<T extends z.ZodTypeAny>(schema: T, data: unknown): z.infer<T> {
  const r = schema.safeParse(data ?? {});
  if (!r.success) throw new HttpError(400, r.error.issues.map(i => `${i.path.join('.') || 'body'}: ${i.message}`).join('; '));
  return r.data;
}
function requireUser(c: Ctx): User {
  if (!c.user) throw new HttpError(401, 'Please sign in.');
  return c.user;
}
function requireAdmin(c: Ctx): User {
  const u = requireUser(c);
  if (!hasRole(u, 'admin')) throw new HttpError(403, 'Admins only.');
  return u;
}
function audit(c: Ctx, action: string, targetType?: string, targetId?: string, details?: object) {
  c.db.prepare('INSERT INTO audit_logs (id, actor_id, action, target_type, target_id, details, ip) VALUES (?,?,?,?,?,?,?)')
    .run(randomUUID(), c.user?.id ?? null, action, targetType ?? null, targetId ?? null, details ? JSON.stringify(details) : null, c.ip);
}
const now = () => new Date().toISOString();

// ---- validation schemas --------------------------------------------------
const username = z.string().trim().toLowerCase().regex(/^[a-z0-9_.]{3,30}$/, 'use 3–30 letters, numbers, dots or underscores');
const password = z.string().min(8, 'must be at least 8 characters').max(128);
const classLevel = z.enum(['JHS1', 'JHS2', 'JHS3', 'SHS1', 'SHS2', 'SHS3']);
const examTarget = z.enum(['BECE', 'WASSCE']);
const RegisterBody = z.object({ username, password, displayName: z.string().trim().min(1).max(40), classLevel: classLevel.optional(), examTarget: examTarget.optional() });
const LoginBody = z.object({ username, password: z.string().min(1).max(128) });
const ProfileBody = z.object({
  displayName: z.string().trim().min(1).max(40).optional(),
  classLevel: classLevel.nullable().optional(),
  examTarget: examTarget.nullable().optional(),
  examDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
  dailyGoalMinutes: z.number().int().min(5).max(600).optional(),
});
const VerificationBody = z.object({ role: z.enum(['teacher', 'school_rep', 'src_officer']) });
const AdminUserBody = z.object({
  role: z.enum(ROLES).optional(),
  verificationStatus: z.enum(['not_required', 'pending', 'verified', 'rejected']).optional(),
  isActive: z.boolean().optional(),
});

function profileOf(db: DB, userId: string) {
  return db.prepare('SELECT class_level, exam_target, exam_date, daily_goal_minutes FROM student_profiles WHERE user_id = ?').get(userId) ?? null;
}
const publicUser = (u: User) => ({ id: u.id, username: u.username, displayName: u.display_name, role: u.role, verificationStatus: u.verification_status, isAdmin: hasRole(u, 'admin') });

// ---- routes ----------------------------------------------------------------
const routes: [string, RegExp, string[], Handler][] = [];
function route(method: string, path: string, h: Handler) {
  const keys: string[] = [];
  const re = new RegExp('^' + path.replace(/:(\w+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '$');
  routes.push([method, re, keys, h]);
}

route('GET', '/api/health', () => ({ ok: true }));

route('POST', '/api/auth/register', c => {
  rateLimit('reg:' + c.ip, 10, 60_000);
  const b = parse(RegisterBody, c.body);
  if (c.db.prepare('SELECT 1 FROM users WHERE username = ?').get(b.username)) throw new HttpError(409, 'That username is taken.');
  const id = randomUUID();
  c.db.exec('BEGIN');
  try {
    c.db.prepare('INSERT INTO users (id, username, password_hash, display_name) VALUES (?,?,?,?)').run(id, b.username, hashPassword(b.password), b.displayName);
    c.db.prepare('INSERT INTO student_profiles (user_id, class_level, exam_target) VALUES (?,?,?)').run(id, b.classLevel ?? null, b.examTarget ?? null);
    c.db.exec('COMMIT');
  } catch (e) { c.db.exec('ROLLBACK'); throw e; }
  c.user = { id } as User; // the new user is the actor of their own registration
  audit(c, 'user.register', 'user', id);
  return { token: createSession(c.db, id) };
});

route('POST', '/api/auth/login', c => {
  rateLimit('login:' + c.ip, 10, 60_000);
  const b = parse(LoginBody, c.body);
  const row = c.db.prepare('SELECT id, password_hash, is_active FROM users WHERE username = ?').get(b.username) as { id: string; password_hash: string; is_active: number } | undefined;
  if (!row || !verifyPassword(b.password, row.password_hash)) throw new HttpError(401, 'Wrong username or password.');
  if (!row.is_active) throw new HttpError(403, 'This account has been deactivated.');
  return { token: createSession(c.db, row.id) };
});

route('POST', '/api/auth/logout', c => {
  const token = (c.req.headers.authorization ?? '').replace(/^Bearer /, '');
  if (token) deleteSession(c.db, token);
  return { ok: true };
});

route('GET', '/api/me', c => {
  const u = requireUser(c);
  return { user: publicUser(u), profile: profileOf(c.db, u.id) };
});

route('PATCH', '/api/me/profile', c => {
  const u = requireUser(c);
  const b = parse(ProfileBody, c.body);
  if (b.displayName) c.db.prepare('UPDATE users SET display_name = ?, updated_at = ? WHERE id = ?').run(b.displayName, now(), u.id);
  const cur = (profileOf(c.db, u.id) ?? {}) as Record<string, unknown>;
  const pick = <K extends keyof typeof b>(k: K, col: string) => (b[k] !== undefined ? b[k] : cur[col] ?? null);
  c.db.prepare(
    `INSERT INTO student_profiles (user_id, class_level, exam_target, exam_date, daily_goal_minutes, updated_at) VALUES (?,?,?,?,?,?)
     ON CONFLICT (user_id) DO UPDATE SET class_level = excluded.class_level, exam_target = excluded.exam_target,
       exam_date = excluded.exam_date, daily_goal_minutes = excluded.daily_goal_minutes, updated_at = excluded.updated_at`,
  ).run(u.id, pick('classLevel', 'class_level') as any, pick('examTarget', 'exam_target') as any, pick('examDate', 'exam_date') as any,
    (b.dailyGoalMinutes ?? cur.daily_goal_minutes ?? 30) as number, now());
  return { profile: profileOf(c.db, u.id) };
});

route('POST', '/api/me/verification-request', c => {
  const u = requireUser(c);
  if (u.role === 'admin') throw new HttpError(400, 'Admins cannot request another role.');
  const b = parse(VerificationBody, c.body);
  c.db.prepare("UPDATE users SET role = ?, verification_status = 'pending', updated_at = ? WHERE id = ?").run(b.role, now(), u.id);
  audit(c, 'user.verification_requested', 'user', u.id, { role: b.role });
  return { ok: true };
});

route('DELETE', '/api/me', c => {
  const u = requireUser(c);
  audit(c, 'user.self_delete', 'user', u.id);
  c.db.prepare('DELETE FROM users WHERE id = ?').run(u.id); // cascades to sessions, profile, attempts
  return { ok: true };
});

route('GET', '/api/home', c => {
  const u = requireUser(c);
  const p = profileOf(c.db, u.id) as { exam_target: string | null; exam_date: string | null; daily_goal_minutes: number } | null;
  const today = new Date().toISOString().slice(0, 10);
  const minutes = Math.round(((c.db.prepare('SELECT COALESCE(SUM(time_spent_s),0) AS s FROM attempts WHERE user_id = ? AND created_at >= ?').get(u.id, today) as { s: number }).s) / 60);
  const daysToExam = p?.exam_date ? Math.ceil((Date.parse(p.exam_date) - Date.parse(today)) / 864e5) : null;
  // Weak topics: lowest accuracy topics with at least 3 attempts. Empty until students practise.
  const weakTopics = c.db.prepare(
    `SELECT t.id, t.name, COUNT(*) AS attempts, AVG(a.is_correct) AS accuracy
     FROM attempts a JOIN question_dna d ON d.question_id = a.question_id JOIN topics t ON t.id = d.topic_id
     WHERE a.user_id = ? AND a.is_correct IS NOT NULL GROUP BY t.id, t.name HAVING COUNT(*) >= 3 ORDER BY accuracy ASC LIMIT 3`,
  ).all(u.id);
  const verifiedQuestions = (c.db.prepare("SELECT COUNT(*) AS n FROM questions WHERE verification_status = 'verified'").get() as { n: number }).n;
  return { displayName: u.display_name, examTarget: p?.exam_target ?? null, examDate: p?.exam_date ?? null, daysToExam, minutesToday: minutes, dailyGoalMinutes: p?.daily_goal_minutes ?? 30, weakTopics, verifiedQuestions };
});

route('GET', '/api/subjects', c => ({ subjects: c.db.prepare('SELECT id, slug, name FROM subjects ORDER BY name').all() }));

// ---- admin ---------------------------------------------------------------
route('GET', '/api/admin/stats', c => {
  requireAdmin(c);
  const n = (sql: string) => (c.db.prepare(sql).get() as { n: number }).n;
  return {
    users: n('SELECT COUNT(*) AS n FROM users'),
    students: n("SELECT COUNT(*) AS n FROM users WHERE role = 'student'"),
    pendingVerifications: n("SELECT COUNT(*) AS n FROM users WHERE verification_status = 'pending'"),
    questions: n('SELECT COUNT(*) AS n FROM questions'),
    verifiedQuestions: n("SELECT COUNT(*) AS n FROM questions WHERE verification_status = 'verified'"),
  };
});

route('GET', '/api/admin/users', c => {
  requireAdmin(c);
  const q = `%${(c.url.searchParams.get('q') ?? '').toLowerCase()}%`;
  const pending = c.url.searchParams.get('pending') === '1';
  const users = c.db.prepare(
    `SELECT id, username, display_name, role, verification_status, is_active, created_at FROM users
     WHERE (username LIKE ? OR LOWER(display_name) LIKE ?) ${pending ? "AND verification_status = 'pending'" : ''}
     ORDER BY created_at DESC LIMIT 100`,
  ).all(q, q);
  return { users };
});

route('PATCH', '/api/admin/users/:id', c => {
  const admin = requireAdmin(c);
  const b = parse(AdminUserBody, c.body);
  const target = c.db.prepare('SELECT id, role, verification_status, is_active FROM users WHERE id = ?').get(c.params.id) as Record<string, unknown> | undefined;
  if (!target) throw new HttpError(404, 'User not found.');
  if (target.id === admin.id && (b.role && b.role !== 'admin' || b.isActive === false)) throw new HttpError(400, 'You cannot demote or deactivate yourself.');
  const role = b.role ?? target.role;
  let status = b.verificationStatus ?? target.verification_status;
  if (role === 'student') status = 'not_required';
  else if (b.role && b.role !== target.role && !b.verificationStatus) status = 'pending';
  const active = b.isActive === undefined ? target.is_active : b.isActive ? 1 : 0;
  c.db.prepare('UPDATE users SET role = ?, verification_status = ?, is_active = ?, updated_at = ? WHERE id = ?').run(role as string, status as string, active as number, now(), target.id as string);
  if (active === 0) c.db.prepare('DELETE FROM sessions WHERE user_id = ?').run(target.id as string);
  audit(c, 'admin.user_update', 'user', target.id as string, { before: target, after: { role, verification_status: status, is_active: active } });
  return { ok: true };
});

route('GET', '/api/admin/audit', c => {
  requireAdmin(c);
  return {
    entries: c.db.prepare(
      `SELECT a.id, a.action, a.target_type, a.target_id, a.details, a.created_at, u.username AS actor
       FROM audit_logs a LEFT JOIN users u ON u.id = a.actor_id ORDER BY a.created_at DESC LIMIT 100`,
    ).all(),
  };
});

// ---- server ----------------------------------------------------------------
async function readBody(req: IncomingMessage): Promise<unknown> {
  if (req.method === 'GET' || req.method === 'HEAD') return undefined;
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const ch of req) {
    size += ch.length;
    if (size > 64 * 1024) throw new HttpError(413, 'Request too large.');
    chunks.push(ch);
  }
  if (!size) return undefined;
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new HttpError(400, 'Invalid JSON.'); }
}

async function serveStatic(pathname: string, res: ServerResponse) {
  const safe = normalize(pathname).replace(/^(\.\.[/\\])+/, '');
  let file = join(STATIC_DIR, safe);
  if (!file.startsWith(STATIC_DIR)) file = join(STATIC_DIR, 'index.html');
  try { if (!(await stat(file)).isFile()) throw 0; } catch { file = join(STATIC_DIR, 'index.html'); } // SPA fallback
  try {
    const data = await readFile(file);
    const cache = file.endsWith('index.html') ? 'no-cache' : 'public, max-age=3600';
    res.writeHead(200, { ...SECURITY_HEADERS, 'Content-Type': MIME[extname(file)] ?? 'application/octet-stream', 'Cache-Control': cache });
    res.end(data);
  } catch {
    res.writeHead(404, SECURITY_HEADERS).end('Frontend not built. Run: npm run build');
  }
}

export function createApp(db: DB) {
  return createServer(async (req, res) => {
    const started = Date.now();
    const url = new URL(req.url ?? '/', 'http://local');
    const ip = (req.socket.remoteAddress ?? 'unknown');
    if (!url.pathname.startsWith('/api/')) return serveStatic(url.pathname, res);
    let status = 200;
    let payload: unknown;
    try {
      const match = routes.find(([m, re]) => m === req.method && re.test(url.pathname));
      if (!match) throw new HttpError(404, 'Not found.');
      const [, re, keys, handler] = match;
      const vals = url.pathname.match(re)!.slice(1);
      const params = Object.fromEntries(keys.map((k, i) => [k, decodeURIComponent(vals[i])]));
      const token = (req.headers.authorization ?? '').replace(/^Bearer /, '') || undefined;
      const ctx: Ctx = { req, res, db, params, url, ip, body: await readBody(req), user: userFromToken(db, token) };
      payload = await handler(ctx);
    } catch (e) {
      if (e instanceof HttpError) { status = e.status; payload = { error: e.message }; }
      else { status = 500; payload = { error: 'Something went wrong on our side.' }; log.error('unhandled', { path: url.pathname, err: String((e as Error)?.stack ?? e) }); }
    }
    res.writeHead(status, { ...SECURITY_HEADERS, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(payload));
    log.info('req', { m: req.method, p: url.pathname, s: status, ms: Date.now() - started });
  });
}
