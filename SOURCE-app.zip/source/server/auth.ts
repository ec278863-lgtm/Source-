import { scryptSync, randomBytes, timingSafeEqual, createHash, randomUUID } from 'node:crypto';
import type { DB } from './db.ts';

export const ROLES = ['student', 'teacher', 'school_rep', 'src_officer', 'moderator', 'admin'] as const;
export type Role = typeof ROLES[number];
export interface User { id: string; username: string; display_name: string; role: Role; verification_status: string; is_active: number }

const SESSION_DAYS = 30;

export function hashPassword(pw: string): string {
  const salt = randomBytes(16);
  const key = scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
}

export function verifyPassword(pw: string, stored: string): boolean {
  const [alg, s, k] = stored.split('$');
  if (alg !== 'scrypt' || !s || !k) return false;
  const expected = Buffer.from(k, 'base64');
  const actual = scryptSync(pw, Buffer.from(s, 'base64'), expected.length, { N: 16384, r: 8, p: 1 });
  return timingSafeEqual(actual, expected);
}

const sha = (t: string) => createHash('sha256').update(t).digest('hex');

/** Opaque random token; only its hash is stored, so a DB leak can't be replayed. */
export function createSession(db: DB, userId: string): string {
  const token = randomBytes(32).toString('base64url');
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5).toISOString();
  db.prepare('INSERT INTO sessions (id, user_id, token_hash, expires_at) VALUES (?,?,?,?)').run(randomUUID(), userId, sha(token), expires);
  return token;
}

export function userFromToken(db: DB, token: string | undefined): User | null {
  if (!token) return null;
  const row = db.prepare(
    `SELECT u.id, u.username, u.display_name, u.role, u.verification_status, u.is_active, s.expires_at
     FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`,
  ).get(sha(token)) as (User & { expires_at: string }) | undefined;
  if (!row || row.expires_at < new Date().toISOString() || !row.is_active) return null;
  const { expires_at, ...user } = row;
  return user;
}

export function deleteSession(db: DB, token: string) {
  db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha(token));
}

/** Elevated roles only count once an admin has verified the person. Enforced server-side. */
export function hasRole(user: User | null, ...roles: Role[]): boolean {
  if (!user || !roles.includes(user.role)) return false;
  return user.role === 'student' || user.verification_status === 'verified';
}
