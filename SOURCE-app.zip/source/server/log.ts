// Structured JSON logs (one line per event) — easy to ship to any log service.
type Level = 'info' | 'warn' | 'error';
const quiet = process.env.LOG_LEVEL === 'silent';
function write(level: Level, msg: string, meta?: Record<string, unknown>) {
  if (quiet && level !== 'error') return;
  const line = JSON.stringify({ t: new Date().toISOString(), level, msg, ...meta });
  (level === 'error' ? process.stderr : process.stdout).write(line + '\n');
}
export const log = {
  info: (m: string, meta?: Record<string, unknown>) => write('info', m, meta),
  warn: (m: string, meta?: Record<string, unknown>) => write('warn', m, meta),
  error: (m: string, meta?: Record<string, unknown>) => write('error', m, meta),
};
