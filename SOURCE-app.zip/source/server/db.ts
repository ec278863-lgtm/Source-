import { DatabaseSync } from 'node:sqlite';
import { readdirSync, readFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { log } from './log.ts';

const MIGRATIONS_DIR = join(import.meta.dirname, '..', 'db', 'migrations');

export type DB = DatabaseSync;

export function openDb(file: string): DB {
  if (file !== ':memory:') mkdirSync(dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;');
  migrate(db);
  seed(db);
  return db;
}

function migrate(db: DB) {
  db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)');
  const done = new Set((db.prepare('SELECT name FROM schema_migrations').all() as { name: string }[]).map(r => r.name));
  for (const f of readdirSync(MIGRATIONS_DIR).filter(f => f.endsWith('.sql')).sort()) {
    if (done.has(f)) continue;
    db.exec('BEGIN');
    try {
      db.exec(readFileSync(join(MIGRATIONS_DIR, f), 'utf8'));
      db.prepare('INSERT INTO schema_migrations (name) VALUES (?)').run(f);
      db.exec('COMMIT');
      log.info('migration applied', { name: f });
    } catch (e) {
      db.exec('ROLLBACK');
      throw e;
    }
  }
}

// Only reference data that is not in doubt. Subject-to-exam mapping and syllabus
// versions are loaded in Stage 2 from official GES/NaCCA/WAEC sources.
const EXAMS: [string, string, string][] = [
  ['BECE', 'Basic Education Certificate Examination', 'JHS'],
  ['WASSCE', 'West African Senior School Certificate Examination', 'SHS'],
];
const SUBJECTS = [
  'English Language', 'Mathematics', 'Integrated Science', 'Social Studies', 'Biology', 'Chemistry',
  'Physics', 'Economics', 'Geography', 'Government', 'Financial Accounting', 'Literature in English', 'ICT',
];

function seed(db: DB) {
  const insExam = db.prepare('INSERT INTO exams (id, code, name, level) VALUES (?,?,?,?) ON CONFLICT (code) DO NOTHING');
  for (const [code, name, level] of EXAMS) insExam.run(randomUUID(), code, name, level);
  const insSub = db.prepare('INSERT INTO subjects (id, slug, name) VALUES (?,?,?) ON CONFLICT (slug) DO NOTHING');
  for (const name of SUBJECTS) insSub.run(randomUUID(), name.toLowerCase().replace(/[^a-z0-9]+/g, '-'), name);
}
