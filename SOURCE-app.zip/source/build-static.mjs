// Builds the standalone app into docs/ (GitHub Pages + Android APK): node build-static.mjs
// docs/index.html contains the whole app; the other files make it installable and offline-capable.
import * as esbuild from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync, copyFileSync } from 'node:fs';

const opts = { bundle: true, minify: true, write: false, target: 'es2020', jsx: 'automatic', outdir: 'out' };
const js = (await esbuild.build({ ...opts, entryPoints: ['web/src/main.tsx'], format: 'iife',
  define: { 'process.env.NODE_ENV': '"production"', __STATIC__: 'true' } })).outputFiles[0].text;
const css = (await esbuild.build({ ...opts, entryPoints: ['web/src/styles.css'] })).outputFiles[0].text;
const icon = 'data:image/svg+xml;base64,' + readFileSync('web/public/icon.svg').toString('base64');

const pwa = `<link rel="manifest" href="manifest.webmanifest" />
  <link rel="apple-touch-icon" href="icon-192.png" />
  <script>if ('serviceWorker' in navigator && location.protocol.startsWith('http')) addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));</script>`;

const html = readFileSync('web/public/index.html', 'utf8')
  .replace('<link rel="icon" href="/icon.svg" type="image/svg+xml" />', () => `<link rel="icon" href="${icon}" type="image/svg+xml" />\n  ${pwa}`)
  .replace('<link rel="stylesheet" href="/styles.css" />', () => `<style>${css}</style>`)
  .replace('<script src="/app.js"></script>', () => `<script>${js.replaceAll('"/icon.svg"', JSON.stringify(icon)).replaceAll('</script', '<\\/script')}</script>`);

mkdirSync('docs', { recursive: true });
writeFileSync('docs/index.html', html);
for (const f of ['manifest.webmanifest', 'sw.js', 'icon-192.png', 'icon-512.png', 'icon-maskable.png']) copyFileSync(`web/public/${f}`, `docs/${f}`);
console.log(`docs/ built (index.html ${(html.length / 1024).toFixed(0)} KB)`);
