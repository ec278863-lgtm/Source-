import * as esbuild from 'esbuild';
import { cpSync, mkdirSync } from 'node:fs';

const watch = process.argv.includes('--watch');
mkdirSync('web/dist', { recursive: true });
cpSync('web/public', 'web/dist', { recursive: true });

const ctx = await esbuild.context({
  entryPoints: { app: 'web/src/main.tsx', styles: 'web/src/styles.css' },
  bundle: true,
  minify: !watch,
  sourcemap: watch,
  target: 'es2020', // older Android WebViews
  outdir: 'web/dist',
  jsx: 'automatic',
  define: { 'process.env.NODE_ENV': watch ? '"development"' : '"production"', __STATIC__: 'false' },
  logLevel: 'info',
});
if (watch) await ctx.watch(); else { await ctx.rebuild(); await ctx.dispose(); }
